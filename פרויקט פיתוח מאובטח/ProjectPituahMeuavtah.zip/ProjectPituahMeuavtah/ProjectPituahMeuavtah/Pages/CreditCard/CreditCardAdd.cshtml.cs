using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProjectPituahMeuavtah.Pages.Products;
using System;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;

namespace ProjectPituahMeuavtah.Pages.CreditCard
{
    public class CreditCardAddModel : PageModel
    {
        public CreditCard creditCard = new CreditCard();


        public void OnGet()
        {
        }

        public void OnPost()
        {
            creditCard.Name = Request.Form["Name"];
            creditCard.CardNumber = Request.Form["CardNumber"];
            creditCard.Expiration = Request.Form["Expiration"];
            creditCard.CVV = Request.Form["CVV"];

            string last4Digits = creditCard.CardNumber.Substring(creditCard.CardNumber.Length - 4);



            if (creditCard.Name.Length == 0 || creditCard.CardNumber.Length != 16 || creditCard.Expiration.Length != 5 || creditCard.CVV.Length != 3)
            {
                return;
            }

            byte[] creditCardBytes = Encoding.UTF8.GetBytes(creditCard.CardNumber);
            byte[] hashedBytes;
            using (SHA256 sha256 = SHA256.Create())
            {
                hashedBytes = sha256.ComputeHash(creditCardBytes);
            }
            string hashedCreditCardNumber = BitConverter.ToString(hashedBytes).Replace("-", "");


            try
            {
                String connectionString = "Data Source=DESKTOP-DJ1JDMN\\SQLEXPRESS;Initial Catalog=storageDB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "INSERT INTO CreditCards " +
                        "(Name, CardNumber, Expiration,last4Digits, CVV) VALUES " +
                        "(@Name, @CardNumber, @Expiration,@last4Digits, @CVV);";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@Name", creditCard.Name);
                        command.Parameters.AddWithValue("@CardNumber", hashedCreditCardNumber);
                        command.Parameters.AddWithValue("@Expiration", creditCard.Expiration);
                        command.Parameters.AddWithValue("@last4Digits", last4Digits);
                        command.Parameters.AddWithValue("@CVV", creditCard.CVV);
                        command.ExecuteNonQuery();
                    }
                }
            }

            catch (Exception)
            {
                return;
            }

            Response.Redirect("/Products/Index");

        }
    }

    public class CreditCard
    {
        public string Name;
        public string CardNumber;
        public string Expiration;
        public string Last4Digits;
        public string CVV;
    }


}