﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProjectPituahMeuavtah.Pages.Products;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;
using ProjectPituahMeuavtah.Pages.CreditCard;

namespace ProjectPituahMeuavtah.Pages.Orders
{
    public class OrdersModel : PageModel
    {
        public List<CreditCard> creditCards = new List<CreditCard>();
        public ProductInfo productInfo = new ProductInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {

            String productNumber = Request.Query["id"];

            try
            {
                String connectionString = "Data Source=DESKTOP-DJ1JDMN\\SQLEXPRESS;Initial Catalog=storageDB;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM products WHERE productNumber=@productNumber";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@productNumber", productNumber);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                productInfo.productNumber = "" + reader.GetInt32(0);
                                productInfo.productName = reader.GetString(1);
                                productInfo.productDescription = reader.GetString(2);
                                productInfo.productImporterCompany = reader.GetString(3);
                            }
                        }

                    }



                    String sqlOfCreditCards = "SELECT * FROM CreditCards";
                    using (SqlCommand command = new SqlCommand(sqlOfCreditCards, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                CreditCard creditCard = new CreditCard();
                                creditCard.Id = "" + reader.GetInt32(0);
                                creditCard.Last4Digits = reader.GetString(4);
                                creditCards.Add(creditCard);
                            }

                        }

                    }



                }
            }

            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

        }

        public Dictionary<string, string> countriesList = new Dictionary<string, string>() {
   { "Afghanistan", "93" },
   { "Åland Islands", "358" },
   { "Albania", "355" },
   { "Algeria", "213" },
   { "American Samoa", "1" },
   { "Andorra", "376" },
   { "Angola", "244" },
   { "Anguilla", "1" },
   { "Antigua and Barbuda", "1" },
   { "Argentina", "54" },
   { "Armenia", "374" },
   { "Aruba", "297" },
   { "Australia", "61" },
   { "Austria", "43" },
   { "Azerbaijan", "994" },
   { "Bahamas", "1" },
   { "Bahrain", "973" },
   { "Bangladesh", "880" },
   { "Barbados", "1" },
   { "Belarus", "375" },
   { "Belgium", "32" },
   { "Belize", "501" },
   { "Benin", "229" },
   { "Bermuda", "1" },
   { "Bhutan", "975" },
   { "Bolivia", "591" },
   { "Bonaire, Sint Eustatius and Saba", "599" },
   { "Bosnia and Herzegovina", "387" },
   { "Botswana", "267" },
   { "Brazil", "55" },
   { "British Indian Ocean Territory", "246" },
   { "British Virgin Islands", "1" },
   { "Brunei", "673" },
   { "Bulgaria", "359" },
   { "Burkina Faso", "226" },
   { "Burundi", "257" },
   { "Cabo Verde", "238" },
   { "Cambodia", "855" },
   { "Cameroon", "237" },
   { "Canada", "1" },
   { "Caribbean", "0" },
   { "Cayman Islands", "1" },
   { "Central African Republic", "236" },
   { "Chad", "235" },
   { "Chile", "56" },
   { "China", "86" },
   { "Christmas Island", "61" },
   { "Cocos (Keeling) Islands", "61" },
   { "Colombia", "57" },
   { "Comoros", "269" },
   { "Congo", "242" },
   { "Congo (DRC)", "243" },
   { "Cook Islands", "682" },
   { "Costa Rica", "506" },
   { "Côte d’Ivoire", "225" },
   { "Croatia", "385" },
   { "Cuba", "53" },
   { "Curaçao", "599" },
   { "Cyprus", "357" },
   { "Czechia", "420" },
   { "Denmark", "45" },
   { "Djibouti", "253" },
   { "Dominica", "1" },
   { "Dominican Republic", "1" },
   { "Ecuador", "593" },
   { "Egypt", "20" },
   { "El Salvador", "503" },
   { "Equatorial Guinea", "240" },
   { "Eritrea", "291" },
   { "Estonia", "372" },
   { "Ethiopia", "251" },
   { "Europe", "0" },
   { "Falkland Islands", "500" },
   { "Faroe Islands", "298" },
   { "Fiji", "679" },
   { "Finland", "358" },
   { "France", "33" },
   { "French Guiana", "594" },
   { "French Polynesia", "689" },
   { "Gabon", "241" },
   { "Gambia", "220" },
   { "Georgia", "995" },
   { "Germany", "49" },
   { "Ghana", "233" },
   { "Gibraltar", "350" },
   { "Greece", "30" },
   { "Greenland", "299" },
   { "Grenada", "1" },
   { "Guadeloupe", "590" },
   { "Guam", "1" },
   { "Guatemala", "502" },
   { "Guernsey", "44" },
   { "Guinea", "224" },
   { "Guinea-Bissau", "245" },
   { "Guyana", "592" },
   { "Haiti", "509" },
   { "Honduras", "504" },
   { "Hong Kong SAR", "852" },
   { "Hungary", "36" },
   { "Iceland", "354" },
   { "India", "91" },
   { "Indonesia", "62" },
   { "Iran", "98" },
   { "Iraq", "964" },
   { "Ireland", "353" },
   { "Isle of Man", "44" },
   { "Israel", "972" },
   { "Italy", "39" },
   { "Jamaica", "1" },
   { "Japan", "81" },
   { "Jersey", "44" },
   { "Jordan", "962" },
   { "Kazakhstan", "7" },
   { "Kenya", "254" },
   { "Kiribati", "686" },
   { "Korea", "82" },
   { "Kosovo", "383" },
   { "Kuwait", "965" },
   { "Kyrgyzstan", "996" },
   { "Laos", "856" },
   { "Latin America", "0" },
   { "Latvia", "371" },
   { "Lebanon", "961" },
   { "Lesotho", "266" },
   { "Liberia", "231" },
   { "Libya", "218" },
   { "Liechtenstein", "423" },
   { "Lithuania", "370" },
   { "Luxembourg", "352" },
   { "Macao SAR", "853" },
   { "Macedonia, FYRO", "389" },
   { "Madagascar", "261" },
   { "Malawi", "265" },
   { "Malaysia", "60" },
   { "Maldives", "960" },
   { "Mali", "223" },
   { "Malta", "356" },
   { "Marshall Islands", "692" },
   { "Martinique", "596" },
   { "Mauritania", "222" },
   { "Mauritius", "230" },
   { "Mayotte", "262" },
   { "Mexico", "52" },
   { "Micronesia", "691" },
   { "Moldova", "373" },
   { "Monaco", "377" },
   { "Mongolia", "976" },
   { "Montenegro", "382" },
   { "Montserrat", "1" },
   { "Morocco", "212" },
   { "Mozambique", "258" },
   { "Myanmar", "95" },
   { "Namibia", "264" },
   { "Nauru", "674" },
   { "Nepal", "977" },
   { "Netherlands", "31" },
   { "New Caledonia", "687" },
   { "New Zealand", "64" },
   { "Nicaragua", "505" },
   { "Niger", "227" },
   { "Nigeria", "234" },
   { "Niue", "683" },
   { "Norfolk Island", "672" },
   { "North Korea", "850" },
   { "Northern Mariana Islands", "1" },
   { "Norway", "47" },
   { "Oman", "968" },
   { "Pakistan", "92" },
   { "Palau", "680" },
   { "Palestinian Authority", "970" },
   { "Panama", "507" },
   { "Papua New Guinea", "675" },
   { "Paraguay", "595" },
   { "Peru", "51" },
   { "Philippines", "63" },
   { "Pitcairn Islands", "0" },
   { "Poland", "48" },
   { "Portugal", "351" },
   { "Puerto Rico", "1" },
   { "Qatar", "974" },
   { "Réunion", "262" },
   { "Romania", "40" },
   { "Russia", "7" },
   { "Rwanda", "250" },
   { "Saint Barthélemy", "590" },
   { "Saint Kitts and Nevis", "1" },
   { "Saint Lucia", "1" },
   { "Saint Martin", "590" },
   { "Saint Pierre and Miquelon", "508" },
   { "Saint Vincent and the Grenadines", "1" },
   { "Samoa", "685" },
   { "San Marino", "378" },
   { "São Tomé and Príncipe", "239" },
   { "Saudi Arabia", "966" },
   { "Senegal", "221" },
   { "Serbia", "381" },
   { "Seychelles", "248" },
   { "Sierra Leone", "232" },
   { "Singapore", "65" },
   { "Sint Maarten", "1" },
   { "Slovakia", "421" },
   { "Slovenia", "386" },
   { "Solomon Islands", "677" },
   { "Somalia", "252" },
   { "South Africa", "27" },
   { "South Sudan", "211" },
   { "Spain", "34" },
   { "Sri Lanka", "94" },
   { "St Helena, Ascension, Tristan da Cunha", "290" },
   { "Sudan", "249" },
   { "Suriname", "597" },
   { "Svalbard and Jan Mayen", "47" },
   { "Swaziland", "268" },
   { "Sweden", "46" },
   { "Switzerland", "41" },
   { "Syria", "963" },
   { "Taiwan", "886" },
   { "Tajikistan", "992" },
   { "Tanzania", "255" },
   { "Thailand", "66" },
   { "Timor-Leste", "670" },
   { "Togo", "228" },
   { "Tokelau", "690" },
   { "Tonga", "676" },
   { "Trinidad and Tobago", "1" },
   { "Tunisia", "216" },
   { "Turkey", "90" },
   { "Turkmenistan", "993" },
   { "Turks and Caicos Islands", "1" },
   { "Tuvalu", "688" },
   { "U.S. Outlying Islands", "0" },
   { "U.S. Virgin Islands", "1" },
   { "Uganda", "256" },
   { "Ukraine", "380" },
   { "United Arab Emirates", "971" },
   { "United Kingdom", "44" },
   { "United States", "1" },
   { "Uruguay", "598" },
   { "Uzbekistan", "998" },
   { "Vanuatu", "678" },
   { "Vatican City", "39" },
   { "Venezuela", "58" },
   { "Vietnam", "84" },
   { "Wallis and Futuna", "681" },
   { "World", "0" },
   { "Yemen", "967" },
   { "Zambia", "260" },
   { "Zimbabwe", "263" },
};

        private void SendEmailButton_Click(string email, string address, string country, string productName)
        {
            // TODO: Replace with the email address you want to send the email to
            string recipientEmailAddress = email;

            // TODO: Replace with the email address and password for the Gmail account you want to use to send the email
            string senderEmailAddress = "yair1616432@gmail.com";
            string senderEmailPassword = "cqpehbvyczfthbdz";

            // Create the email message
            MailMessage message = new MailMessage(senderEmailAddress, recipientEmailAddress);
            message.Subject = $"{productName} Send";
            message.Body = @$"Dear customer,
Thank you for your recent purchase of {productName} by using our delivery company we will reach {address}, {country} soon as possible. We appreciate your business and hope you are enjoying your new {productName}.
If you have any questions or concerns about your purchase, please do not hesitate to contact our customer service team by the mail: yair1616432@gmail.com. We are always here to help.
Thank you again for choosing our store for your shopping needs
Best regards,
The UPCHITA team";

            // Create the email client
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.Credentials = new NetworkCredential(senderEmailAddress, senderEmailPassword);
            client.EnableSsl = true;

            // Send the email
            client.Send(message);
        }

        public void OnPost()
        {
            string clientEmail = Request.Form["clientEmail"];
            string country = Request.Form["Country"];
            string address = Request.Form["Address"];
            string productName = Request.Form["productName"];

            if(country.Length > 0)
            {
            country = country.Replace("[", "");
            int ind = country.IndexOf(",");
            country = country.Substring(0, ind);
            }





            if (clientEmail.Length == 0 || country.Length == 0 || address.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }
            else
            {
                /*              successMessage = "The package send to client in " + address + ", " + country; */

                SendEmailButton_Click(clientEmail, address, country, productName);

                Response.Redirect("/Products/Index");
            }


        }
    }
    public class CreditCard
    {
        public string Id;
        public string Name;
        public string CardNumber;
        public string Expiration;
        public string Last4Digits;
        public string CVV;
    }
}


