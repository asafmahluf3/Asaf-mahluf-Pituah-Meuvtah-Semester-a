using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Net.Security;

namespace ProjectPituahMeuavtah.Pages.Products
{
    public class IndexModel : PageModel
    {
        public List<ProductInfo> listProducts = new List<ProductInfo>();
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=DESKTOP-DJ1JDMN\\SQLEXPRESS;Initial Catalog=storageDB;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM products";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ProductInfo productInfo = new ProductInfo();
                                productInfo.productNumber = "" + reader.GetInt32(0);
                                productInfo.productName = reader.GetString(1);
                                productInfo.productDescription = reader.GetString(2);
                                productInfo.productImporterCompany = reader.GetString(3);
                                productInfo.created_at = reader.GetDateTime(4).ToString();

                                listProducts.Add(productInfo);
                            }
                        }

                    }


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
    }

    public class ProductInfo
    {
        public string productNumber;
        public string productName;
        public string productDescription;
        public string productImporterCompany;
        public string created_at;
    }
}
