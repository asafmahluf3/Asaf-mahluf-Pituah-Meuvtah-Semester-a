using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace ProjectPituahMeuavtah.Pages.Products
{
    public class EditModel : PageModel
    {

        public ProductInfo productInfo = new ProductInfo();
        public String errorMessage = "";
        public String successMessage = "";

        public void OnGet()
        {
            String productNumber = Request.Query["id"];

            try
            {
                String connectionString = "Data Source=DESKTOP-DJ1JDMN\\SQLEXPRESS;Initial Catalog=storageDB;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM products WHERE productNumber=@productNumber";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@productNumber", productNumber);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                productInfo.productNumber = "" + reader.GetInt32(0);
                                productInfo.productName = reader.GetString(1);
                                productInfo.productDescription = reader.GetString(2);
                                productInfo.productImporterCompany = reader.GetString(3);
                            }
                        }

                    }

                }
            }

            catch (Exception ex)
            {

                errorMessage = ex.Message;
            }

        }

        public void OnPost()
        {
            productInfo.productNumber = Request.Form["productNumber"];
            productInfo.productName = Request.Form["productName"];
            productInfo.productDescription = Request.Form["productDescription"];
            productInfo.productImporterCompany = Request.Form["productImporterCompany"];


            if (productInfo.productName.Length == 0 || productInfo.productDescription.Length == 0 ||
                productInfo.productImporterCompany.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;

            }

            try
            {
                String connectionString = "Data Source=DESKTOP-DJ1JDMN\\SQLEXPRESS;Initial Catalog=storageDB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "UPDATE products " +
                        "SET productName=@productName, productDescription=@productDescription, productImporterCompany=@productImporterCompany " +
                        "WHERE productNumber=@productNumber";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@productNumber", productInfo.productNumber);
                        command.Parameters.AddWithValue("@productName", productInfo.productName);
                        command.Parameters.AddWithValue("@productDescription", productInfo.productDescription);
                        command.Parameters.AddWithValue("@productImporterCompany", productInfo.productImporterCompany);

                        command.ExecuteNonQuery();

                    }


                }
            }

            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            Response.Redirect("/Products/Index");

        }
    }
}
